- Use a messy csv, e.g. IUCN habitat descriptions

coral_spp_narratives <- read_csv('https://raw.githubusercontent.com/OHI-Science/IUCN-AquaMaps/master/clip_depth/coral_spp_narratives.csv')

    - stringr commands
    - regex - incl in list.files()


- text mining packages - 
    - tidytext? 
    - pdf extracting
    - HTML parsing
    - Twitter API?
    
- sentiment analysis

- word clouds