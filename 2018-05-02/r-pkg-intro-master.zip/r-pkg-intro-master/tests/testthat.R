library(testthat)
library(greetings)

test_check("greetings")
